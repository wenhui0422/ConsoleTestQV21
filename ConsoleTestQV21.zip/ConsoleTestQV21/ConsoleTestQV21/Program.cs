﻿/* 
 *      Name:           Program
 *      Author:         Wenhui Fan
 *      Created:        2021/10/12
 *      Last Updated:   2021/10/12
 *      Scope:          Main class for running application
 */

using ConsoleTestQV21.DataModel;
using ConsoleTestQV21.Services;
using SimpleInjector;
using System;
using System.Collections.Generic;
using System.IO;

namespace ConsoleTestQV21
{
    class Program
    {
        static readonly Container container;

        private static string fileName = "Well Data.csv";
        private static readonly string csvFile = Path.Combine(Environment.CurrentDirectory, @"Data\", fileName);

        static Program()
        {
            //Create a new Simple Injector container
            container = new Container();

            //inject service class
            container.Register<IOperationManager, OperationManager>();
            container.Register<FileManager>();
        }

        public static void Main(string[] args)
        {
            var optMgr = container.GetInstance<IOperationManager>();
            Console.WriteLine("*************************************");
            Console.WriteLine("1. Read Well Data File");
            Console.WriteLine("2. Print specific well data");
            Console.WriteLine("3. Print all well data");
            Console.WriteLine("4. Update tank data");
            Console.WriteLine("5. Delete tank data");
            Console.WriteLine("6. Exit");
            Console.WriteLine("*************************************");
            Console.WriteLine("Choose option from 1 to 5 for different operateion, Press enter 6 to exit.");

            bool exiting = false;
            List<Tank> tanks = new List<Tank>();

            Tank tank = new Tank();
            var opt = Console.ReadLine();
            int optValue;
            var mid = string.Empty;

            if (int.TryParse(opt, out optValue)) // Try to parse the string as an integer
            {
                while (true)
                {
                    switch (optValue)
                    {
                        //ReadWellFile
                        case (int)WellDataOperation.ReadWellFile:
                            tanks = FileManager.ReadWelldata(csvFile);
                            Console.WriteLine("Read Well Data Completed.");
                            break;

                        //Print specific well data
                        case (int)WellDataOperation.PrintSpecificWellData:
                            if (tanks == null || tanks.Count == 0)
                            {
                                Console.WriteLine("Please choose the option 1 to read in a well file first.");
                            }
                            else
                            {
                                Console.WriteLine("Please enter Tank MID:");
                                mid = Console.ReadLine();

                                int midValue;
                                if (int.TryParse(mid, out midValue)) // Try to parse the string as an integer
                                {

                                    if (midValue > 0)
                                    {
                                        //mid = 1065;
                                        var tk = optMgr.GetTank(midValue, tanks);
                                        if (tk.TankMID == 0)
                                        {
                                            Console.WriteLine("Not Found Tank data based on Tank MID: {0}", midValue);
                                        }
                                        else
                                        {
                                            Console.WriteLine("Print specific well data");
                                            Console.WriteLine("{0, -25}{1, -20}{2, -20}{3, -20}{4, -20}{5, -20}{6, -20}{7, -20}{8, -20}{9, -20}{10, -20}",
                                                "Owner", "Tank MID", "API #", "Longitude", "Latitude", "PropertyNo", "LeaseWellName", "TankName", "TankNbr", "TankSize", "BBLSPerInch");

                                            optMgr.PrintTankData(tk);
                                        }
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("Not Found Tank data based on Tank MID: {0}", mid);
                                }
                            }
                            break;

                        //Print all well data
                        case (int)WellDataOperation.PrintAllWellData:
                            if (tanks == null || tanks.Count == 0)
                            {
                                Console.WriteLine("Please choose the option 1 to read in a well file first.");
                            }
                            else
                            {
                                Console.WriteLine("Print all well data");
                                Console.WriteLine("{0, -25}{1, -20}{2, -20}{3, -20}{4, -20}{5, -20}{6, -20}{7, -20}{8, -20}{9, -20}{10, -20}",
                                    "Owner", "Tank MID", "API #", "Longitude", "Latitude", "PropertyNo", "LeaseWellName", "TankName", "TankNbr", "TankSize", "BBLSPerInch");
                                var tks = optMgr.GetAllTanks(tanks);
                                foreach (var t in tks)
                                {
                                    optMgr.PrintTankData(t);
                                }
                            }
                            break;

                        //Update tank data
                        case (int)WellDataOperation.UpdateTankData:
                            if (tanks == null || tanks.Count == 0)
                            {
                                Console.WriteLine("Please choose the option 1 to read in a well file first.");
                            }
                            else
                            {
                                //mid = 1065;
                                Console.WriteLine("Please enter Tank MID:");
                                mid = Console.ReadLine();

                                int midValue;
                                if (int.TryParse(mid, out midValue)) // Try to parse the string as an integer
                                {

                                    if (midValue > 0)
                                    {
                                        // this is one example only updating Lease Well Name
                                        tank = new Tank { TankMID = midValue, LeaseWellName = "new Lease/Well Name" }; 
                                        var tk = optMgr.UpdateTank(midValue, tanks, tank);
                                        if (tk.TankMID == 0)
                                        {
                                            Console.WriteLine("Not Found Tank data based on Tank MID: {0}", midValue);
                                        }
                                        else
                                        {
                                            Console.WriteLine("Tank data was Updated.");

                                            var tkv = optMgr.GetTank(midValue, tanks);
                                            Console.WriteLine("{0, -25}{1, -20}{2, -20}{3, -20}{4, -20}{5, -20}{6, -20}{7, -20}{8, -20}{9, -20}{10, -20}",
                                                "Owner", "Tank MID", "API #", "Longitude", "Latitude", "PropertyNo", "LeaseWellName", "TankName", "TankNbr", "TankSize", "BBLSPerInch");
                                            optMgr.PrintTankData(tkv);
                                        }
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("Not Found Tank data based on Tank MID: {0}", mid);
                                }
                            }
                            break;

                        //Delete tank data
                        case (int)WellDataOperation.DeleteTankData:
                            if (tanks == null || tanks.Count == 0)
                            {
                                Console.WriteLine("Please choose the option 1 to read in a well file first.");
                            }
                            else
                            {
                                //mid = 1065;
                                Console.WriteLine("Please enter Tank MID:");
                                mid = Console.ReadLine();

                                int midValue;
                                if (int.TryParse(mid, out midValue)) // Try to parse the string as an integer
                                {
                                    if (midValue > 0)
                                    {
                                        tank = new Tank { TankMID = midValue, APIId = "123" };
                                        var tk = optMgr.DeleteTank(midValue, tanks);
                                        if (tk.TankMID == 0)
                                        {
                                            Console.WriteLine("Not Found Tank data based on Tank MID: {0}", midValue);
                                        }
                                        else
                                        {
                                            Console.WriteLine("Tank data was Deleted.");

                                            var tkv = optMgr.GetTank(midValue, tanks);
                                            Console.WriteLine("{0, -25}{1, -20}{2, -20}{3, -20}{4, -20}{5, -20}{6, -20}{7, -20}{8, -20}{9, -20}{10, -20}",
                                                "Owner", "Tank MID", "API #", "Longitude", "Latitude", "PropertyNo", "LeaseWellName", "TankName", "TankNbr", "TankSize", "BBLSPerInch");
                                            var tks = optMgr.GetAllTanks(tanks);
                                            foreach (var t in tks)
                                            {
                                                optMgr.PrintTankData(t);
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("Not Found Tank data based on Tank MID: {0}", mid);
                                }
                            }
                            break;

                        case (int)WellDataOperation.Exist:
                            Console.WriteLine("Good Bye!");
                            System.Threading.Thread.Sleep(100);
                            exiting = true;
                            break;
                    }

                    if (exiting)
                    {
                        break;
                    }
                    else
                    {
                        Console.WriteLine("*************************************");
                        Console.WriteLine("1. Read Well Data File");
                        Console.WriteLine("2. Print specific well data");
                        Console.WriteLine("3. Print all well data");
                        Console.WriteLine("4. Update tank data");
                        Console.WriteLine("5. Delete tank data");
                        Console.WriteLine("6. Exit");
                        Console.WriteLine("*************************************");
                        Console.WriteLine("Choose option from 1 to 5 for different operateion, Press enter 6 to exit.");

                        opt = Console.ReadLine();
                        if (!int.TryParse(opt, out optValue)) // Try to parse the string as an integer
                        {
                            Console.WriteLine("Please choose option from 1 to 6.");
                        }
                    }
                }
            }
            else
            {
                Console.WriteLine("Please choose option from 1 to 6.");
            }
        }
    }
}
