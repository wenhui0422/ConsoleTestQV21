﻿/* 
 *      Name:           TankViewModel
 *      Author:         Wenhui Fan
 *      Created:        2021/10/12
 *      Last Updated:   2021/10/12
 *      Scope:          TankViewModel is used for output to present infomation on view
 */

namespace ConsoleTestQV21.DataModel
{
    class TankViewModel
    {
        public int TankMID { get; set; }
        public string APIId { get; set; }
        public string Owner { get; set; }
        public string Longitude { get; set; }
        public string Latitude { get; set; }
        public string PropertyNo { get; set; }
        public string LeaseWellName { get; set; }
        public string TankName { get; set; }
        public string TankNbr { get; set; }
        public float TankSize { get; set; }
        public string BBLSPerInch { get; set; }
    }
}
