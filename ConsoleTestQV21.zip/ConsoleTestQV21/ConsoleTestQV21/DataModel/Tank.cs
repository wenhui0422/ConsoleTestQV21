﻿/* 
 *      Name:           Tank
 *      Author:         Wenhui Fan
 *      Created:        2021/10/12
 *      Last Updated:   2021/10/12
 *      Scope:          Tank is a application domain class
 */

using System;

namespace ConsoleTestQV21.DataModel
{
    class Tank
    {
        public int TankMID { get; set; }
        public string APIId { get; set; }
        public string Owner { get; set; }
        public string Longitude { get; set; }
        public string Latitude { get; set; }
        public string PropertyNo { get; set; }
        public string LeaseWellName { get; set; }
        public string TankName { get; set; }
        public string TankNbr { get; set; }
        public float TankSize { get; set; }
        public string BBLSPerInch { get; set; }

        public static Tank FromCsv(string csvLine)
        {
            string[] values = csvLine.Split(',');
            Tank tank = new Tank();
            tank.Owner = Convert.ToString(values[0]);
            tank.TankMID = Convert.ToInt32(values[6]);
            tank.APIId = Convert.ToString(values[1]);
            tank.Longitude = Convert.ToString(values[2]);
            tank.Latitude = Convert.ToString(values[3]);
            tank.PropertyNo = Convert.ToString(values[4]);
            tank.LeaseWellName = Convert.ToString(values[5]);
            tank.TankName = Convert.ToString(values[7]);
            tank.TankNbr = Convert.ToString(values[8]);
            tank.TankSize = (float)Convert.ToDouble(values[9]);
            tank.BBLSPerInch = Convert.ToString(values[10]);
            return tank;
        }
    }
}
