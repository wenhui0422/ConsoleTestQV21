﻿/* 
 *      Name:           WellDataOperation
 *      Author:         Wenhui Fan
 *      Created:        2021/10/12
 *      Last Updated:   2021/10/12
 *      Scope:          WellDataOperation Enum. This files can be exteded with more Enum data type if necessary.
 */

namespace ConsoleTestQV21.DataModel
{
    public enum WellDataOperation
    {
        ReadWellFile = 1,
        PrintSpecificWellData,
        PrintAllWellData,
        UpdateTankData,
        DeleteTankData,
        Exist
    }
}
