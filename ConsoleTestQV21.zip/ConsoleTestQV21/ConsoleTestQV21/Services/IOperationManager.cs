﻿/* 
 *      Name:           IOperationManager
 *      Author:         Wenhui Fan
 *      Created:        2021/10/12
 *      Last Updated:   2021/10/12
 *      Scope:          IOperationManager interface
 */

using ConsoleTestQV21.DataModel;
using System.Collections.Generic;

namespace ConsoleTestQV21.Services
{
    interface IOperationManager
    {
        //print tank data with format
        void PrintTankData(TankViewModel tank);

        //Get specific tank data
        TankViewModel GetTank(int tankMID, List<Tank> Tanks = null);

        //List all tank data
        IEnumerable<TankViewModel> GetAllTanks(List<Tank> Tanks);

        //Update tank data
        Tank UpdateTank(int tankMID, List<Tank> tanks, Tank tank);

        //Delete tank data
        Tank DeleteTank(int tankMID, List<Tank> tanks);
    }
}
