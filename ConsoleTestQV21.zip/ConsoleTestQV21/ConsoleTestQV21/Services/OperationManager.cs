﻿/* 
 *      Name:           OperationManager
 *      Author:         Wenhui Fan
 *      Created:        2021/10/12
 *      Last Updated:   2021/10/12
 *      Scope:          OperationManager class implements the methods in IOperationManager interface
 */

using ConsoleTestQV21.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleTestQV21.Services
{
    class OperationManager : IOperationManager
    {
        //print tank data with format
        void IOperationManager.PrintTankData(TankViewModel tank)
        {
            Console.WriteLine("{0, -25}{1, -20}{2, -20}{3, -20}{4, -20}{5, -20}{6, -20}{7, -20}{8, -20}{9, -20}{10, -20}",
                tank.Owner, tank.TankMID, tank.APIId, tank.Longitude, tank.Latitude, tank.PropertyNo, tank.LeaseWellName, tank.TankName, tank.TankNbr, tank.TankSize, tank.BBLSPerInch);
        }

        //Get specific tank data
        TankViewModel IOperationManager.GetTank(int tankMID, List<Tank> Tanks = null)
        {
            Tanks = Tanks ?? new List<Tank>();
            var tank = Tanks.FindAll(t => t.TankMID == tankMID).FirstOrDefault();
            if (tank != null)
            {
                return new TankViewModel
                {
                    Owner = tank.Owner,
                    TankMID = tank.TankMID,
                    APIId = tank.APIId,
                    Longitude = tank.Longitude,
                    Latitude = tank.Latitude,
                    PropertyNo = tank.PropertyNo,
                    LeaseWellName = tank.LeaseWellName,
                    TankName = tank.TankName,
                    TankNbr = tank.TankNbr,
                    TankSize = tank.TankSize,
                    BBLSPerInch = tank.BBLSPerInch,
                };
            }

            return new TankViewModel();
        }

        //List all tank data
        IEnumerable<TankViewModel> IOperationManager.GetAllTanks(List<Tank> Tanks)
        {
            var tanks = Tanks.Select(x => new TankViewModel
            {
                Owner = x.Owner,
                TankMID = x.TankMID,
                APIId = x.APIId,
                Longitude = x.Longitude,
                Latitude = x.Latitude,
                PropertyNo = x.PropertyNo,
                LeaseWellName = x.LeaseWellName,
                TankName = x.TankName,
                TankNbr = x.TankNbr,
                TankSize = x.TankSize,
                BBLSPerInch = x.BBLSPerInch,
            }).ToList();

            return tanks;
        }

        //Update tank data
        Tank IOperationManager.UpdateTank(int tankMID, List<Tank> tanks, Tank tank)
        {
            try
            {
                Tank tk = tanks.FindAll(x => x.TankMID == tankMID).FirstOrDefault();
                if (tk != null)
                {
                    tk.Owner = tank.Owner;
                    tk.TankMID = tank.TankMID;
                    tk.APIId = tank.APIId;
                    tk.Longitude = tank.Longitude;
                    tk.Latitude = tank.Latitude;
                    tk.PropertyNo = tank.PropertyNo;
                    tk.LeaseWellName = tank.LeaseWellName;
                    tk.TankName = tank.TankName;
                    tk.TankNbr = tank.TankNbr;
                    tk.TankSize = tank.TankSize;
                    tk.BBLSPerInch = tank.BBLSPerInch;

                    Console.WriteLine("Update tank data is processed.");
                    return tk;
                }

                return new Tank();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        //Delete tank data
        Tank IOperationManager.DeleteTank(int tankMID, List<Tank> tanks)
        {
            try
            {
                 Tank tk = tanks.FindAll(x => x.TankMID == tankMID).FirstOrDefault();
                if (tk != null)
                {
                    tanks.Remove(tk);
                    Console.WriteLine("Delete tank data is processed.");

                    return new Tank() { TankMID = tankMID };
                }

                return new Tank();
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
