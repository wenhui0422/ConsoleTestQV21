﻿/* 
 *      Name:           FileManager
 *      Author:         Wenhui Fan
 *      Created:        2021/10/12
 *      Last Updated:   2021/10/12
 *      Scope:          FileManager class for manipulating a file, this class can be exteded with more functions
 */

using ConsoleTestQV21.DataModel;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ConsoleTestQV21.Services
{
    class FileManager
    {
        public static List<Tank> ReadWelldata(string csv)
        {
            if (File.Exists(csv))
            {
                return File.ReadAllLines(csv)
                           .Skip(1)
                           .Select(v => Tank.FromCsv(v)).ToList();
            }

            return new List<Tank>() { };
        }
    }
}
